String pkg = "com.tencent.ig";

if (isChecked) {
    Execc("TURBO 2028 " + pkg);
}
